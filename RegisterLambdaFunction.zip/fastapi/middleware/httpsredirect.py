from starlette.middleware.httpsredirect import HTTPSRedirectMiddleware as HTTPSRedirectMiddleware  # noqa
